Wei Z, Hao J K. A threshold search based memetic algorithm for the disjunctively constrained knapsack problem[J]. Computers & Operations Research, 2021, 136: 105447.

The program 'DCKP_TSBMA' contains three input parameters: InsName Seed InsType.

1) InsName: the name of each instance tested.
2) Seed: the random seed.
3) InsType: the type of each instance tested. There are only two candidate values: 
   	    '1' for the Set I of 100 DCKP instances, '2' for the Set II of 6240 DCKP instances.

The cut-off time for instance Set I is set to 1000 seconds and 600 for Set II.



Keep the program and the benchmark instances in the same folder.

Then the job can be subbmitted as follows:
/************************************************\
./DCKP_TSBMA	InsName	Seed	InsType 
/************************************************\

For example:
./DCKP_TSBMA 1I1 0 1

The results are stored in the text file named "InsName_result.txt".



If you have any questions with this program, please contact:

zequn.wei@gmail.com

Sincere thanks and best regards!
